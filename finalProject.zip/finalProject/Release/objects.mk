################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -llibc.a -l"C:/ti/ccs1250/cc3200-sdk/driverlib/ccs/Release/driverlib.a" -l"C:/ti/ccs1250/cc3200-sdk/simplelink/ccs/NON_OS/simplelink.a"

