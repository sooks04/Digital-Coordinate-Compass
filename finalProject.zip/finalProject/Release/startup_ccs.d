# FIXED

startup_ccs.obj: C:/ti/ccs1250/cc3200-sdk/example/common/startup_ccs.c

C:/ti/ccs1250/cc3200-sdk/example/common/startup_ccs.c:

