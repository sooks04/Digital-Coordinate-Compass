# FIXED

pinmux.obj: ../pinmux.c
pinmux.obj: ../pinmux.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/inc/hw_types.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/inc/hw_memmap.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/inc/hw_gpio.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/driverlib/pin.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/driverlib/rom.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/driverlib/rom_map.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/driverlib/rom_patch.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/driverlib/gpio.h
pinmux.obj: C:/ti/ccs1250/cc3200-sdk/driverlib/prcm.h

../pinmux.c:

../pinmux.h:

C:/ti/ccs1250/cc3200-sdk/inc/hw_types.h:

C:/ti/ccs1250/cc3200-sdk/inc/hw_memmap.h:

C:/ti/ccs1250/cc3200-sdk/inc/hw_gpio.h:

C:/ti/ccs1250/cc3200-sdk/driverlib/pin.h:

C:/ti/ccs1250/cc3200-sdk/driverlib/rom.h:

C:/ti/ccs1250/cc3200-sdk/driverlib/rom_map.h:

C:/ti/ccs1250/cc3200-sdk/driverlib/rom_patch.h:

C:/ti/ccs1250/cc3200-sdk/driverlib/gpio.h:

C:/ti/ccs1250/cc3200-sdk/driverlib/prcm.h:

